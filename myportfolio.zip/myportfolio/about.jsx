import React from "react";
import { motion } from "framer-motion";

export default function AboutMeSection() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-purple-900 to-black text-white px-10 py-20 font-[Poppins]">
      <motion.div 
        initial={{ opacity: 0, y: 50 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 0.8 }}
        className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-16 items-center justify-center"
      >
        <div className="rounded-full border-8 border-white overflow-hidden w-80 h-80 shadow-xl">
          <img
            src="/thanu-image.jpg"
            alt="Thanu Sri"
            className="object-cover w-full h-full grayscale hover:grayscale-0 transition duration-500"
          />
        </div>

        <div className="text-left max-w-xl">
          <h1 className="text-5xl font-extrabold mb-4 text-white drop-shadow-[0_4px_4px_rgba(255,0,255,0.5)]">
            ABOUT ME
          </h1>
          <p className="text-lg mb-6">
            Hey there! I’m <span className="text-pink-500 font-semibold">Thanu</span>, a 19-year-old <span className="text-purple-400">UX/UI Designer, Creative Technologist, Data Analyst</span> and <span className="text-purple-400">Prompt Engineer</span>.
          </p>
          <p className="mb-6">
            I’m passionate about turning ideas into beautiful, meaningful digital experiences. With a natural creative spark and the ability to bring designs to life using AI tools and code platforms, I’ve worked on projects from face recognition apps to trading platforms to educational websites.
          </p>
          <ul className="list-disc list-inside space-y-1 text-white/90">
            <li>🟣 Dancing to my favorite beats</li>
            <li>🟣 Painting the chaos in my head</li>
            <li>
              🟣 Getting lost in novels or horror scripts I write myself (yes, really 👻)
            </li>
          </ul>
          <p className="mt-6 text-neon font-semibold text-pink-500">
            ▶️ I believe creativity isn’t just a skill — it’s my language
          </p>
        </div>
      </motion.div>
    </div>
  );
}
